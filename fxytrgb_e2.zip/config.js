export let Config = {
  min_depth: 14,
  min_expr_depth: 20,
  seed: fxrand() * 4.0,
};
