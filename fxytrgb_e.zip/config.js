export let Config = {
  min_depth: 16,
  min_expr_depth: 16,
  seed: fxrand() * 4.0,
};
